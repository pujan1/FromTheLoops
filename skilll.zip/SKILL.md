---
name: unslop
description: Audit and improve the code quality, readability, and testability of a React or Next.js codebase — especially AI-generated or "vibe-coded" projects with sloppy patterns. Use this whenever the user asks to clean up, refactor, audit, optimize, unslop, lint, harden, or improve a React/Next.js repo, mentions "vibe-coded" or "AI-generated" code, asks to "make this codebase better", asks about code smells, or wants a structured audit report with an interactive checklist. Do not just start refactoring — this skill produces a non-destructive audit report (an `unslop/` folder with an interactive HTML viewer) that the user works through themselves.
---

# unslop

Audits a React / Next.js codebase and produces a non-destructive report in an `unslop/` folder at the project root. The report has an interactive HTML viewer (accordion UI, two tabs: Issues and Workflows) and machine-readable per-issue markdown files with copy-paste-ready fix prompts.

The skill never edits source files. The user (or another Claude session) does the fixing — this skill only finds, categorises, and documents.

## When to invoke

Trigger phrases include: "unslop my repo", "audit this codebase", "clean up this vibe-coded project", "improve code quality of this Next.js app", "find code smells", "make this React project more readable / testable", "review my project for refactor opportunities".

If the user just says "refactor this file" or "fix this bug", that's not this skill — that's targeted editing. This skill is for whole-project audits.

## High-level workflow

1. **Confirm scope.** Detect whether this is React or Next.js, locate the source root, and confirm with the user before scanning a large tree.
2. **Detect architecture pattern.** Read top-level folders and a sample of files. Pick a dominant pattern. Note deviations as their own issue category.
3. **Discover workflows.** From routes (and entry points), enumerate user-facing workflows. For each, walk happy path, error paths, loading state.
4. **Scan for issues.** Walk `references/code-quality-rules.md` rule by rule. Collect instances with `file:line` and a short snippet.
5. **Emit the `unslop/` folder.** Write `issues.json`, `issues/<rule>.md`, `workflows/<name>.md`, and `index.html` (copied from `assets/ui-template.html` with data inlined).
6. **Tell the user how to open it.** "Open `unslop/index.html` in a browser."

## Hard constraints

- **Never modify source files.** This skill is read-only on the project. The output goes only into the new `unslop/` directory.
- **Be honest about scale.** If a rule has 200 hits, do not list 200 in the JSON — group by file with a count, and list at most ~30 representative instances. Note the total.
- **Every issue category needs a fix prompt.** A user should be able to copy the prompt straight into a new Claude session and have it fix that specific issue.
- **Confirm before scanning huge trees.** If the project is >2000 files, ask first whether to scan everything or focus on a subdirectory.

## Step 1 — Confirm scope

Read `package.json`. Confirm:
- `next` is in dependencies → Next.js project.
- Otherwise `react` → React project.
- Neither → tell the user this skill is for React/Next.js and stop.

Identify the source root:
- `src/app/` or `src/pages/` or `app/` or `pages/` → Next.js routes live here.
- `src/` or root-level → general source.

Ask the user a one-liner if anything is ambiguous (e.g. monorepo). Otherwise proceed.

## Step 2 — Detect architecture pattern

Read `references/architecture-detection.md` for the full procedure. Briefly:

- List the immediate children of the source root.
- Match against known patterns (feature-based, type-based, atomic, Next.js app-router with co-located components, hybrid).
- Pick the dominant pattern. Record it.
- During the rule scan in step 4, any file that lives outside the dominant pattern is recorded under the `architecture-inconsistency` category.

## Step 3 — Discover workflows

Read `references/workflow-discovery.md`. Briefly:

- Routes are the entry points. In Next.js, enumerate `app/**/page.tsx` or `pages/**/*.tsx`. In a plain React app, enumerate routes from the router config (look for `react-router`, `tanstack-router`, etc.).
- For each route, identify the workflow it represents (e.g. `/login` → "sign-in workflow").
- For each workflow, document:
  - **Happy path** — what the user sees on success.
  - **Error paths** — 404, validation failure, network error, unauthorized.
  - **Loading state** — what shows during async work.
  - **Components involved** — the tree under that route.
  - **Optimisation notes** — anything you noticed walking it (missing loading state, missing error boundary, etc.).
- Write each workflow as `unslop/workflows/<workflow-slug>.md`. Also emit `unslop/workflows.json` so the HTML viewer can render them.

## Step 4 — Scan for issues

Read `references/code-quality-rules.md` for the full rule catalogue. Rules are grouped into categories:

1. **TypeScript safety** — `any`, redundant type assertions, `Function`/`Object` types, missing return types.
2. **Naming** — cryptic single-letter or abbreviated names, ambiguous booleans, ambiguous event handlers.
3. **File organisation** — helpers inline (should be `*.helper.ts`), constants inline (should be `*.constants.ts`), files >200 lines, components with >5 responsibilities.
4. **React patterns** — array-index keys, inline anonymous handlers in JSX, useEffect dependency issues, prop drilling, direct state mutation, over- or under-memoization.
5. **Next.js patterns** — `<img>` instead of `<Image>`, `<a>` for internal links, unnecessary `'use client'`, hardcoded route strings.
6. **CSS** — unused selectors, hardcoded magic values, duplicate rules, inline styles when a CSS system exists.
7. **Code hygiene** — `console.log`, commented-out code, unused imports/exports, dead code, TODO/FIXME without ticket.
8. **Accessibility** — missing `alt`, missing `aria-label` on icon buttons, non-semantic markup.
9. **Error handling** — missing error boundaries, swallowed errors (`catch {}`), missing loading states.
10. **Testability** — components mixing data-fetching with presentation, hardcoded dependencies, missing or co-located tests.
11. **Architecture inconsistency** — files that violate the dominant pattern detected in step 2.

For each rule, the reference file gives you:
- A short description of what to look for.
- A detection heuristic (regex / AST pattern / structural check).
- A bad → good example.
- A fix prompt template.

Walk the source tree once. For every match, record `{file, line, snippet, ruleId}` into the running aggregate.

## Step 5 — Emit the `unslop/` folder

Read `references/output-format.md` for the exact schemas. Briefly, write into the project root:

```
unslop/
├── index.html              ← copy of assets/ui-template.html with data inlined
├── issues.json             ← aggregated findings
├── workflows.json          ← workflow metadata
├── issues/
│   ├── typescript-any.md
│   ├── unnecessary-as-const.md
│   ├── extract-helpers.md
│   ├── ...                 ← one file per rule that had at least one hit
└── workflows/
    ├── _index.md
    ├── sign-in.md
    ├── checkout.md
    └── ...
```

### Inlining data into index.html

`assets/ui-template.html` contains two placeholder script blocks:

```html
<script id="unslop-issues" type="application/json">{{ISSUES_JSON}}</script>
<script id="unslop-workflows" type="application/json">{{WORKFLOWS_JSON}}</script>
```

Replace both placeholders with the JSON content (no surrounding quotes, just the raw JSON object). The HTML opens directly from disk — no server, no build step.

## Step 6 — Hand off

Tell the user, briefly:

- Where the folder lives (`./unslop/`).
- How to open the report (`open unslop/index.html` on macOS, or just double-click).
- Roughly how many issues across how many categories.
- That the report persists their check-off state in localStorage, so they can work through it across sessions.
- That each issue category has a `.md` file with a fix prompt they can paste into a fresh Claude session.

Do NOT volunteer to start fixing things. The audit is the deliverable. If the user then says "ok, let's fix category X", that's a separate task.

## Output style for the audit summary

Keep the summary short. Something like:

> Scanned `src/` (1,247 files). Detected a feature-based architecture with 12 deviations.
>
> Found **89 issues across 14 categories**. Top three: typescript-any (24), large-files (12), unused-css (11).
>
> Mapped **7 workflows**: sign-in, sign-up, checkout, account, search, product-detail, password-reset. Two are missing error boundaries.
>
> Open `unslop/index.html` to browse. Each category has a fix prompt in `unslop/issues/<id>.md`.

Prose, not bullets unless the count gets unwieldy. The HTML viewer is the rich surface — the chat reply just needs to point at it.

## Reference files

- `references/code-quality-rules.md` — the full rule catalogue (read on every invocation).
- `references/architecture-detection.md` — how to pick the dominant pattern.
- `references/workflow-discovery.md` — how to enumerate and document workflows.
- `references/output-format.md` — schemas and templates for everything in `unslop/`.

## Assets

- `assets/ui-template.html` — copy this into `unslop/index.html` and substitute the two JSON placeholders.
