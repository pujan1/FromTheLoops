# Output format

Exact schemas and templates for every file the skill writes into `unslop/`.

## File layout

```
unslop/
├── index.html              ← copy of assets/ui-template.html with JSON inlined
├── issues.json             ← machine-readable findings
├── workflows.json          ← machine-readable workflows
├── README.md               ← human-readable summary
├── issues/
│   ├── _index.md           ← table of contents of all issue categories
│   ├── typescript-any.md
│   ├── unnecessary-as-const.md
│   └── ...                 ← one .md per rule that had at least one hit
└── workflows/
    ├── _index.md           ← table of contents of all workflows
    ├── sign-in.md
    ├── checkout.md
    └── ...
```

Only emit a file under `issues/<rule>.md` if the rule had at least one hit. Don't write empty files.

## issues.json schema

```json
{
  "meta": {
    "generatedAt": "2026-06-24T12:34:56Z",
    "projectRoot": "src",
    "framework": "next" | "react",
    "architecturePattern": "feature-based" | "type-based" | "atomic" | "nextjs-app-router-plus-shared" | "hybrid",
    "filesScanned": 1247,
    "totalIssues": 89
  },
  "categories": [
    {
      "id": "typescript-safety",
      "label": "TypeScript safety",
      "rules": [
        {
          "id": "typescript-any",
          "label": "Uses of `any`",
          "description": "any opts out of the type system. Most uses can be replaced with a real type or unknown + narrowing.",
          "totalCount": 24,
          "displayedCount": 24,
          "fixPromptPath": "issues/typescript-any.md",
          "instances": [
            {
              "file": "src/lib/api.ts",
              "line": 42,
              "snippet": "function parse(payload: any) {",
              "id": "typescript-any:src/lib/api.ts:42"
            }
          ]
        }
      ]
    }
  ]
}
```

The `id` on each instance is a stable string used as the localStorage key for the "checked off" state in the HTML viewer. Use `<ruleId>:<file>:<line>`.

If a rule has more than ~30 instances, set `displayedCount` to 30 (or whatever you chose) and only include 30 in `instances` — but keep `totalCount` accurate. Add a note in the per-rule `.md` file that the list is sampled.

## workflows.json schema

```json
{
  "meta": {
    "generatedAt": "2026-06-24T12:34:56Z",
    "totalWorkflows": 7
  },
  "workflows": [
    {
      "id": "sign-in",
      "label": "Sign in",
      "routes": ["/login"],
      "summary": "User submits credentials and is redirected to the dashboard.",
      "happyPath": "User enters email + password, submits, server validates, JWT is set in a cookie, user is redirected to /dashboard.",
      "errorPaths": [
        {
          "name": "Invalid credentials",
          "handled": true,
          "notes": "Inline error rendered under the form."
        },
        {
          "name": "Network failure",
          "handled": false,
          "notes": "No retry UI; component renders blank on fetch rejection."
        }
      ],
      "loadingState": {
        "present": true,
        "kind": "spinner",
        "notes": "Button shows a spinner while submitting."
      },
      "componentsInvolved": [
        "app/login/page.tsx",
        "components/auth/LoginForm.tsx",
        "lib/auth.ts"
      ],
      "linkedIssueIds": [
        "missing-error-boundaries:app/login/page.tsx",
        "swallowed-errors:lib/auth.ts:88"
      ],
      "optimisationNotes": "Consider debouncing the email validity check; right now it fires on every keystroke.",
      "docPath": "workflows/sign-in.md"
    }
  ]
}
```

`linkedIssueIds` reference instance ids from `issues.json`. The viewer uses these to cross-link.

## issues/<rule>.md template

```markdown
# <rule label>

**Category:** <category label>
**Total occurrences:** <N>
**Displayed:** <M> of <N>  ← only include this line if M < N

## What it is

<short description from the rule>

## Why it matters

<rationale>

## Instances

| File | Line | Snippet |
|------|------|---------|
| src/lib/api.ts | 42 | `function parse(payload: any) {` |
| src/hooks/useUser.ts | 17 | `const user: any = ...` |
| ... |

## Fix prompt

Copy this into a new Claude (or Cursor / Aider / Copilot Chat) session:

> <the fix prompt template from the rule, with the path to this file substituted>

## Notes

- Files where this rule appears most often: src/lib/api.ts (8), src/components/Form.tsx (4)
- Consider fixing the cluster first — same root cause is likely.
```

## workflows/<slug>.md template

```markdown
# <workflow label>

**Routes:** /login
**Components:** app/login/page.tsx, components/auth/LoginForm.tsx, lib/auth.ts

## Summary

<one-paragraph summary>

## Happy path

<step-by-step prose>

1. User lands on /login.
2. Enters email + password.
3. Submits the form.
4. Server validates and returns a session token.
5. Token stored in httpOnly cookie.
6. User is redirected to /dashboard.

## Error paths

### Invalid credentials
- **Handled:** yes
- **Notes:** Inline error rendered under the form.

### Network failure
- **Handled:** no
- **Notes:** The component renders blank when `fetch` rejects. No retry UI.
- **Linked issues:** [swallowed-errors:lib/auth.ts:88](../issues/swallowed-errors.md)

### Unauthorised (token expired mid-session)
- **Handled:** partial
- **Notes:** Some routes redirect; others 500.

## Loading state

- **Present:** yes
- **Kind:** spinner inside submit button
- **Notes:** No skeleton on the page itself; whole form is interactive during load.

## Optimisation notes

- Email validity check fires on every keystroke — consider debouncing.
- The session token is re-validated on every navigation — could be cached for the session lifetime.
- The error message for "invalid credentials" is generic — consider distinguishing "no such user" vs "wrong password" (subject to security policy).

## Linked issues

- [missing-error-boundaries](../issues/missing-error-boundaries.md) — no error boundary above /login
- [swallowed-errors:lib/auth.ts:88](../issues/swallowed-errors.md) — catch swallows the fetch rejection
```

## issues/_index.md and workflows/_index.md

Simple tables of contents. Generated from the JSON.

```markdown
# Issues index

| Category | Rule | Count |
|----------|------|-------|
| TypeScript safety | [Uses of `any`](typescript-any.md) | 24 |
| ... |
```

## README.md (at unslop root)

```markdown
# unslop report

Generated <date> against <projectRoot>.

## Summary

- Framework: <framework>
- Architecture pattern: <pattern>
- Files scanned: <N>
- Total issues: <M> across <K> categories
- Workflows mapped: <W>

## How to use

1. Open `index.html` in a browser. Click through the accordion to browse issues by category.
2. Check off instances as you fix them — the state persists in your browser's localStorage.
3. For each category, the "Copy fix prompt" button gives you a prompt to paste into a fresh AI assistant session, scoped to that category. Each prompt references the relevant `.md` file in `issues/`.
4. The "Workflows" tab documents user-facing flows with happy and error paths. Use these as your test scaffolding.

## Top categories by count

1. <rule>: <count>
2. <rule>: <count>
3. <rule>: <count>

## Things to fix first

(Suggestions ordered roughly by impact / blast radius.)

1. <suggestion>
2. <suggestion>
```

## How the HTML viewer reads this

`assets/ui-template.html` has two placeholders:

```html
<script id="unslop-issues" type="application/json">{{ISSUES_JSON}}</script>
<script id="unslop-workflows" type="application/json">{{WORKFLOWS_JSON}}</script>
```

Substitute both with the raw JSON content (no escaping needed beyond what JSON already does — the `type="application/json"` script tag treats the content as inert text). The page then `JSON.parse`s both on load.

## Validation before writing

Before writing the final files, sanity-check:
- Every `linkedIssueIds` in workflows.json refers to an instance id that exists in issues.json.
- Every rule with `totalCount > 0` has a corresponding `issues/<id>.md` file.
- Every workflow has a corresponding `workflows/<slug>.md`.
- The `meta.totalIssues` in issues.json equals the sum of all `totalCount` across rules.
