# Code quality rules

The full catalogue of issues to scan for. Each rule has:
- **id**: kebab-case, used as the filename and JSON key
- **category**: high-level grouping
- **what to look for**: detection heuristic
- **why it matters**: one-sentence rationale
- **bad → good**: minimal example
- **fix prompt**: a template the user can paste into a Claude session to fix all instances

When scanning, walk every source file once and tag any line that matches a rule. Aggregate into `{ruleId: [{file, line, snippet}]}`. Cap instances per rule at ~30 representative samples but report the true total count.

---

## Category 1 — TypeScript safety

### `typescript-any`
**What to look for:** `: any`, `as any`, `Array<any>`, `any[]`, function returns/parameters typed as `any`. Ignore inside `.d.ts` files only if the project's own type ambient files (those in `*.d.ts` at the repo root or `types/`) — third-party shims under `node_modules` are out of scope anyway.
**Why it matters:** `any` opts out of the type system. Most uses are reachable with a real type, a generic, or `unknown` + narrowing.
**Bad:** `function handle(payload: any) { ... }`
**Good:** `function handle(payload: WebhookPayload) { ... }` or `function handle(payload: unknown) { /* narrow */ }`
**Fix prompt:**
> Look at each occurrence of `any` in `unslop/issues/typescript-any.md`. For each, infer the real type from how the value is used (call sites, property access, function returns) and replace `any` with that type, or with `unknown` plus narrowing if the value is genuinely dynamic. Don't add new `any`s. Don't suppress with `// @ts-ignore` — fix the type.

### `redundant-type-assertions`
**What to look for:** `as Foo` where TS would already infer `Foo`. Also `as const` on values that are already narrow literals (e.g. `5 as const`, `"foo" as const` where the value isn't widened). Also double-assertions `as unknown as Foo`.
**Why it matters:** Assertions silence the type checker. Where they're not load-bearing, removing them lets TS catch real mismatches.
**Bad:** `const port: number = 3000 as const`
**Good:** `const port = 3000` (TS infers `number`; if you need literal `3000`, use `const port = 3000 as const` without the redundant annotation)
**Note:** `as const` on object literals and arrays *is* load-bearing — it narrows to literal types and adds `readonly`. Only flag when the assertion is provably redundant.
**Fix prompt:**
> For each entry in `unslop/issues/redundant-type-assertions.md`, evaluate whether the assertion is doing work. If TypeScript would infer the same (or a strictly more useful) type without it, remove the assertion. Keep assertions that genuinely narrow (e.g. tuple types on arrays, readonly object literals, narrowing from `unknown`).

### `function-and-object-types`
**What to look for:** parameter or property types declared as `Function`, `Object`, or `{}`.
**Why it matters:** These types are nearly equivalent to `any` and disable useful checking.
**Bad:** `onClick: Function`
**Good:** `onClick: (event: MouseEvent) => void`
**Fix prompt:**
> Replace each `Function`/`Object`/`{}` typing in `unslop/issues/function-and-object-types.md` with a precise signature or interface based on usage.

### `missing-return-types-on-exports`
**What to look for:** exported functions / hooks without an explicit return type annotation.
**Why it matters:** Exports are a public API. Inferred return types can drift silently across refactors.
**Bad:** `export function useAuth() { ... }`
**Good:** `export function useAuth(): AuthState { ... }`
**Fix prompt:**
> Add explicit return type annotations to every exported function/hook listed in `unslop/issues/missing-return-types-on-exports.md`. Infer from current behavior; do not change runtime behavior.

---

## Category 2 — Naming

### `cryptic-names`
**What to look for:** single-letter identifiers outside conventional contexts (loop index `i`, math `x`/`y`, event `e`), aggressive abbreviation (`tmstps`, `usr`, `prj`, `t` for "timestamps").
**Why it matters:** Readability. The next reader (often the same person two months later) shouldn't have to reconstruct intent from context.
**Bad:** `for (const t of timeStamps) { ... }`
**Good:** `for (const timestamp of timestamps) { ... }`
**Fix prompt:**
> Rename each cryptic identifier in `unslop/issues/cryptic-names.md` to a clear, descriptive name. Keep conventional short names (`i` for indices, `e` for events, `x`/`y` for coordinates, `_` for unused). Use refactor-rename so all references update.

### `ambiguous-booleans`
**What to look for:** boolean variables or props without `is`/`has`/`should`/`can` prefix (e.g. `disable`, `loading`, `active` when the intent is a flag).
**Why it matters:** `disable` reads as an imperative; `isDisabled` reads as a state.
**Bad:** `<Button disable={true} />`
**Good:** `<Button isDisabled={true} />`
**Note:** Some libraries (e.g. shadcn, Radix) use `disabled` by convention — don't flag those.
**Fix prompt:**
> Rename boolean variables and props listed in `unslop/issues/ambiguous-booleans.md` to use `is`/`has`/`should`/`can` prefixes. Skip cases where you're matching an external library's prop name.

### `inconsistent-handler-names`
**What to look for:** mixed use of `onX` (props) and `handleX` (locals). The convention is: props named `onClick`, local handlers named `handleClick`. Flag files that mix conventions on the same kind of thing.
**Why it matters:** Consistency makes scanning a file fast.
**Bad:** `<button onClick={clickHandler}>` next to `<button onClick={handleSubmit}>`
**Good:** consistent `handleClick`, `handleSubmit`, etc.
**Fix prompt:**
> Rename handler functions in `unslop/issues/inconsistent-handler-names.md` to follow the `handleX` convention for local definitions and `onX` for component props.

---

## Category 3 — File organisation

### `extract-helpers`
**What to look for:** non-trivial pure functions defined inside a component file but not used as hooks or JSX. Anything >5 lines that doesn't reference component state/props should probably move to a sibling `<componentName>.helper.ts`.
**Why it matters:** Component files should be about rendering. Pulling helpers out makes them testable and importable elsewhere.
**Bad:**
```tsx
// Profile.tsx
function formatJoinedDate(iso: string): string { /* 12 lines */ }
export function Profile() { ... }
```
**Good:**
```tsx
// Profile.helper.ts
export function formatJoinedDate(iso: string): string { /* 12 lines */ }

// Profile.tsx
import { formatJoinedDate } from './Profile.helper'
export function Profile() { ... }
```
**Fix prompt:**
> For each helper listed in `unslop/issues/extract-helpers.md`, move the function to a sibling `<ComponentName>.helper.ts` file, export it, and import it back into the component. Add a focused unit test for each extracted helper if a test directory exists.

### `extract-constants`
**What to look for:** literal arrays, lookup objects, enums-as-objects, regex patterns defined inline at module top level or inside components. Anything that "feels like" configuration.
**Why it matters:** Constants drift when copied; centralising them stops divergence. Also surfaces them to grep.
**Bad:**
```tsx
const STATUS_COLORS = { active: 'green', pending: 'orange', closed: 'gray' }
export function Badge() { ... }
```
**Good:**
```ts
// Badge.constants.ts
export const STATUS_COLORS = { active: 'green', pending: 'orange', closed: 'gray' } as const

// Badge.tsx
import { STATUS_COLORS } from './Badge.constants'
```
**Fix prompt:**
> Extract the constants listed in `unslop/issues/extract-constants.md` into a sibling `<ComponentName>.constants.ts` file. Add `as const` where the value is a literal object/array intended to be readonly with narrow types.

### `large-files`
**What to look for:** files >200 lines (warning), >400 lines (definite).
**Why it matters:** Long files usually do too many things. Split by responsibility, not by line count — but the length itself is the signal.
**Heuristic for splitting:**
- Multiple components in one file → one file per component.
- Component + giant helpers → extract helpers (see `extract-helpers`).
- Component + giant types → extract to `<name>.types.ts`.
- Component + many sub-components only used here → make a folder: `ComponentName/index.tsx`, `ComponentName/SubThing.tsx`.
**Fix prompt:**
> For each oversized file in `unslop/issues/large-files.md`, propose a split into smaller files by responsibility. Show the proposed file tree before making changes. Then move code, update imports, and run the build to confirm nothing broke.

### `dead-exports`
**What to look for:** exported symbols never imported anywhere in the project. Use a static analysis tool (`ts-prune`, `knip`) if available, or grep-based heuristic across the source tree.
**Why it matters:** Dead exports keep dead code alive.
**Fix prompt:**
> For each export listed in `unslop/issues/dead-exports.md`, verify there are no remaining imports (check tests, stories, config). If truly unused, delete the export and any code that's only reachable through it.

---

## Category 4 — React patterns

### `array-index-as-key`
**What to look for:** `.map((item, i) => <X key={i} />)` or `key={index}`.
**Why it matters:** Index keys break reconciliation when the list reorders, leading to subtle bugs (form state on the wrong row, transitions misfiring).
**Bad:** `items.map((item, i) => <Row key={i} item={item} />)`
**Good:** `items.map(item => <Row key={item.id} item={item} />)`
**Note:** Index keys are fine for static lists that never reorder, but the default assumption should be a stable id.
**Fix prompt:**
> For each occurrence in `unslop/issues/array-index-as-key.md`, replace the index key with a stable identifier from the item. If the item has no stable id, generate one when the data is created, not at render time.

### `inline-anonymous-handlers`
**What to look for:** `<button onClick={() => { /* multi-statement body */ }}>` or arrow functions creating closures with non-trivial logic inside JSX. Trivial one-liners (`() => setOpen(true)`) are usually fine.
**Why it matters:** Non-trivial inline handlers obscure the JSX and force re-creation of the function each render. Pull them out as `handleX` for readability.
**Bad:**
```tsx
<button onClick={() => {
  setLoading(true)
  fetcher().then(setData).finally(() => setLoading(false))
}}>Load</button>
```
**Good:**
```tsx
const handleLoad = () => {
  setLoading(true)
  fetcher().then(setData).finally(() => setLoading(false))
}
return <button onClick={handleLoad}>Load</button>
```
**Fix prompt:**
> Extract each multi-statement inline handler in `unslop/issues/inline-anonymous-handlers.md` to a named `handleX` local. Leave trivial one-liner handlers as-is.

### `useeffect-dependency-issues`
**What to look for:** `useEffect` calls where the dependency array is missing, empty when it shouldn't be (effect uses props/state), or includes objects/arrays recreated each render. The `react-hooks/exhaustive-deps` ESLint rule is the canonical check.
**Why it matters:** Wrong dep arrays are the #1 source of stale closures and infinite loops.
**Fix prompt:**
> Review each useEffect listed in `unslop/issues/useeffect-dependency-issues.md`. For each, decide whether the missing dep should be added (most cases) or whether the effect should be refactored (e.g. moved into an event handler, memoized, or replaced with a derived value). Don't blindly add deps to silence the warning — understand each case.

### `direct-state-mutation`
**What to look for:** `state.push(...)`, `state.x = ...` followed by a `setState(state)` call. Also `Object.assign(state, ...)` patterns.
**Why it matters:** React compares by reference. Mutating in place doesn't trigger re-renders reliably.
**Bad:** `items.push(newItem); setItems(items)`
**Good:** `setItems([...items, newItem])` or `setItems(prev => [...prev, newItem])`
**Fix prompt:**
> Replace each direct mutation in `unslop/issues/direct-state-mutation.md` with an immutable update (spread, `map`, `filter`, or a library like Immer if already in the project).

### `prop-drilling`
**What to look for:** the same prop passed through ≥3 levels of components without being consumed.
**Why it matters:** A signal that context, composition, or a state library would clean things up.
**Note:** This rule needs care. Sometimes drilling is fine. Flag it for human review, don't auto-recommend a fix.
**Fix prompt:**
> For each chain in `unslop/issues/prop-drilling.md`, propose either: (a) a React context if the value is genuinely global to a subtree, (b) composition / children-as-render-prop, or (c) a state library if the project already has one. Show the proposed shape before refactoring.

### `over-or-under-memoization`
**What to look for:**
- `useMemo`/`useCallback` wrapping trivial values (e.g. `useMemo(() => 5, [])`).
- Expensive computations in render with no memoization (e.g. `.filter().sort().reduce()` over large lists).
**Why it matters:** Both extremes hurt — wasteful memo bookkeeping vs. unnecessary recomputation.
**Fix prompt:**
> For each entry in `unslop/issues/over-or-under-memoization.md`, decide based on the actual work being done. Strip memos around cheap values. Add memos around demonstrably expensive computations or callbacks passed to memoized children.

---

## Category 5 — Next.js patterns

### `img-instead-of-next-image`
**What to look for:** `<img ... />` tags in a Next.js project where `next/image`'s `<Image>` would work.
**Why it matters:** `<Image>` does responsive sizing, lazy loading, modern format negotiation, and layout-shift prevention automatically.
**Note:** External images that aren't whitelisted in `next.config.js`'s `images.domains` would need configuration. Flag those separately.
**Fix prompt:**
> Replace each `<img>` in `unslop/issues/img-instead-of-next-image.md` with `<Image>` from `next/image`. For external sources, add the domain to `images.remotePatterns` in `next.config.js`. Confirm width/height are set or `fill` is used appropriately.

### `a-instead-of-link`
**What to look for:** `<a href="/...">` for internal routes in a Next.js project.
**Why it matters:** `<Link>` does client-side routing and prefetching. Plain `<a>` forces a full page reload.
**Bad:** `<a href="/profile">Profile</a>`
**Good:** `<Link href="/profile">Profile</Link>`
**Fix prompt:**
> Replace each internal-link `<a>` in `unslop/issues/a-instead-of-link.md` with `<Link>` from `next/link`. Keep `<a>` only for external URLs and mailto/tel links.

### `unnecessary-use-client`
**What to look for:** files starting with `'use client'` that don't actually use any client-only features (no `useState`, `useEffect`, event handlers, browser APIs).
**Why it matters:** `'use client'` opts the file (and its deps) out of server rendering, increasing bundle size.
**Fix prompt:**
> For each file in `unslop/issues/unnecessary-use-client.md`, confirm none of: hooks, event handlers, `window`/`document` access, or third-party client-only libs are used. If clean, remove the directive. If the file is imported by something that does need it, the directive may still be load-bearing for descendants — verify.

### `hardcoded-route-strings`
**What to look for:** route strings like `'/dashboard/settings'` scattered across the codebase.
**Why it matters:** Renaming a route requires grep-and-pray. A central `routes.ts` makes this safe.
**Fix prompt:**
> Centralise route strings from `unslop/issues/hardcoded-route-strings.md` into a `src/routes.ts` (or wherever the project's conventions dictate) as a typed `const routes = { dashboard: { settings: '/dashboard/settings' } } as const` object. Replace each call site.

---

## Category 6 — CSS

### `unused-css`
**What to look for:** CSS selectors, classes, or CSS module exports never referenced in any TSX/JSX/HTML.
**Why it matters:** Dead CSS bloats the bundle and confuses readers.
**Detection:** For CSS Modules, parse the module file's exports, then grep usage in the colocated component. For global CSS, harder — flag conservatively.
**Fix prompt:**
> Remove each unused selector listed in `unslop/issues/unused-css.md`. Run the build and a visual smoke test to confirm nothing regressed.

### `hardcoded-design-values`
**What to look for:** hex colors, raw px values, font sizes scattered in CSS where the project has design tokens / a theme.
**Why it matters:** Tokens centralise the design system; hardcoded values fork it.
**Fix prompt:**
> Replace hardcoded design values in `unslop/issues/hardcoded-design-values.md` with references to design tokens (CSS variables, Tailwind theme, MUI theme, etc., depending on the project's stack).

### `duplicate-css-rules`
**What to look for:** identical rule blocks across files, or rules that fully override each other.
**Why it matters:** Duplication leads to drift.
**Fix prompt:**
> Consolidate duplicate rules from `unslop/issues/duplicate-css-rules.md` into a shared module or utility class.

### `inline-styles-when-system-exists`
**What to look for:** `style={{ ... }}` props in files where the project has Tailwind / CSS modules / styled-components.
**Why it matters:** Inline styles bypass the styling system, don't get themed, and don't get linted.
**Note:** Some inline styles are unavoidable (dynamic values driven by state, e.g. `style={{ width: pct + '%' }}`). Don't flag those.
**Fix prompt:**
> Convert the static inline styles in `unslop/issues/inline-styles-when-system-exists.md` to the project's styling system. Keep dynamic styles inline.

---

## Category 7 — Code hygiene

### `console-statements`
**What to look for:** `console.log`, `console.warn`, `console.debug`, etc. outside of explicitly designated logger files.
**Why it matters:** Production noise, leaked debug info, and a missing logging strategy.
**Fix prompt:**
> Remove or replace each `console.*` in `unslop/issues/console-statements.md`. Use the project's logger if one exists. Keep only intentional `console.error` in error paths if there's no logger.

### `commented-out-code`
**What to look for:** blocks of commented code (multi-line comment containing code-like tokens).
**Why it matters:** Version control is for history. Commented-out code rots and confuses.
**Fix prompt:**
> Delete commented-out code blocks in `unslop/issues/commented-out-code.md`. If a block is intentionally a "future use" example, convert it to a documented explanation in the comment.

### `unused-imports`
**What to look for:** imports never referenced. ESLint's `no-unused-vars` covers this, but flag all instances in the report.
**Why it matters:** Build noise, bundle bloat (depending on tree-shaking).
**Fix prompt:**
> Remove unused imports from files in `unslop/issues/unused-imports.md`. Run `tsc` to confirm nothing breaks.

### `todo-without-context`
**What to look for:** `// TODO`, `// FIXME`, `// XXX` without an issue ID, author, or date.
**Why it matters:** Anonymous TODOs accumulate forever.
**Bad:** `// TODO: fix this`
**Good:** `// TODO(JIRA-123): handle pagination correctly`
**Fix prompt:**
> For each TODO in `unslop/issues/todo-without-context.md`, either: (a) fix the issue if small, (b) open a ticket and reference it in the comment, or (c) delete the TODO if it's no longer relevant.

---

## Category 8 — Accessibility

### `missing-alt-text`
**What to look for:** `<img>` / `<Image>` without `alt` prop.
**Why it matters:** Screen readers, plus basic ARIA hygiene.
**Note:** Decorative images should have `alt=""` (intentionally empty) — that's correct, not missing.
**Fix prompt:**
> Add meaningful `alt` text to each image in `unslop/issues/missing-alt-text.md`. Use `alt=""` only for truly decorative images.

### `icon-button-without-label`
**What to look for:** buttons whose only child is an icon component, with no `aria-label`.
**Why it matters:** Screen reader users get "button" with no context.
**Bad:** `<button><CloseIcon /></button>`
**Good:** `<button aria-label="Close dialog"><CloseIcon /></button>`
**Fix prompt:**
> Add `aria-label` to each icon-only button in `unslop/issues/icon-button-without-label.md`.

### `non-semantic-markup`
**What to look for:** `<div onClick={...}>` for interactive things; `<div>` stacks where a `<header>`/`<main>`/`<nav>`/`<article>` would fit.
**Why it matters:** Semantics improve a11y, SEO, and reader comprehension.
**Fix prompt:**
> Replace clickable `<div>`s in `unslop/issues/non-semantic-markup.md` with `<button>` (or `<a>` if navigation). Replace structural `<div>`s with semantic landmarks where appropriate.

---

## Category 9 — Error handling

### `missing-error-boundaries`
**What to look for:** route segments / top-level component subtrees with no error boundary above them. In Next.js app router, each route segment should have an `error.tsx` for graceful degradation.
**Why it matters:** One render error takes the whole tree down without a boundary.
**Fix prompt:**
> For each subtree in `unslop/issues/missing-error-boundaries.md`, add a route-level `error.tsx` (Next.js) or wrap with an `ErrorBoundary` component. Show a user-friendly fallback with a retry action.

### `swallowed-errors`
**What to look for:** `catch (e) {}`, `catch { /* nothing */ }`, or `catch (e) { console.log(e) }` without further handling.
**Why it matters:** Silent failures are debugging nightmares.
**Fix prompt:**
> Review each swallowed catch in `unslop/issues/swallowed-errors.md`. Decide for each: surface to the user (toast / error UI), report to monitoring, or genuinely ignore with a comment explaining why.

### `missing-loading-states`
**What to look for:** components that fetch data but render nothing during the loading window (no skeleton, no spinner, no "Loading…").
**Why it matters:** Users see a blank screen, perceive the app as broken.
**Fix prompt:**
> Add explicit loading UI to each component in `unslop/issues/missing-loading-states.md`. Prefer skeletons over spinners when the layout is known.

---

## Category 10 — Testability

### `mixed-data-and-presentation`
**What to look for:** components that both call `fetch`/`useQuery`/etc. AND render complex UI. These are hard to test in isolation.
**Why it matters:** Splitting the "container" (data) from the "presentational" (UI) makes both testable in isolation.
**Fix prompt:**
> Split each component in `unslop/issues/mixed-data-and-presentation.md` into a data-fetching wrapper and a presentational inner component that takes the data as props. The presentational component should be testable with static props and no mocks.

### `missing-tests-for-critical-paths`
**What to look for:** workflow entry points (route components, top-level business logic) with no co-located test file (`<name>.test.ts(x)` or `__tests__/<name>.test.tsx`).
**Why it matters:** Critical paths break silently.
**Fix prompt:**
> Add at least one happy-path test for each component listed in `unslop/issues/missing-tests-for-critical-paths.md`, using the project's existing test framework. Cover the documented workflow's primary success scenario.

---

## Category 11 — Architecture inconsistency

### `architecture-inconsistency`
**What to look for:** files that don't fit the dominant pattern detected in step 2 of the workflow (e.g. a `features/` folder when the project is otherwise type-based; a `components/Foo.tsx` when the project is feature-based).
**Why it matters:** Inconsistency makes new contributors guess where things live.
**Fix prompt:**
> For each outlier in `unslop/issues/architecture-inconsistency.md`, decide: either move the file into the dominant pattern, or — if the outlier is actually a better pattern and you want to adopt it project-wide — make that decision explicit and migrate the rest. Don't leave the inconsistency unresolved.
