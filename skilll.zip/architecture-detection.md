# Architecture detection

The skill needs to pick a single "dominant pattern" for the project so that deviations can be flagged as `architecture-inconsistency`. This file explains how.

## Common patterns

### Type-based (a.k.a. "Rails-like")
Top-level folders group by *kind of thing*:
```
src/
├── components/
├── hooks/
├── utils/
├── types/
├── lib/
└── pages/    (or app/)
```
**Signal:** the top level has folders like `components`, `hooks`, `utils`, `services`, `lib`. Most code lives under `components/`.
**Variants:** sometimes flattened (`src/components/Header.tsx`), sometimes nested (`src/components/Header/index.tsx`).

### Feature-based
Top-level folders group by *feature*:
```
src/
├── features/
│   ├── auth/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── api.ts
│   │   └── index.ts
│   ├── checkout/
│   └── profile/
├── shared/
│   ├── components/
│   └── hooks/
└── app/
```
**Signal:** a `features/` or `modules/` folder at the top level, each child containing its own components/hooks/types/api.
**Variants:** sometimes uses `domains/` instead of `features/`. Sometimes the shared folder is `common/` or `core/`.

### Atomic design
Folders named after atomic levels:
```
src/
├── atoms/
├── molecules/
├── organisms/
├── templates/
└── pages/
```
**Signal:** the words `atoms`, `molecules`, `organisms` show up as folder names. Rare in modern Next.js codebases but you'll see it.

### Next.js app-router (route co-location)
Folders inside `app/` correspond to URL segments; each route can have local `components/`, `_components/`, etc.:
```
app/
├── (marketing)/
│   ├── page.tsx
│   └── _components/
├── dashboard/
│   ├── layout.tsx
│   ├── page.tsx
│   ├── settings/
│   │   └── page.tsx
│   └── _components/
└── api/
```
**Signal:** an `app/` directory with `page.tsx` files. Local `_components/` or `components/` folders alongside routes.

### Hybrid
Many real projects are hybrid: an `app/` directory for Next.js routes plus a top-level `src/components/` and `src/lib/` for shared things. That's a legitimate pattern, not slop — call it "Next.js app-router + shared".

## Detection procedure

1. **List the immediate children of the source root** (`src/` or repo root). Capture their names.
2. **Score against the patterns above.** For each pattern, count how many of its signal folders are present.
3. **Pick the highest-scoring pattern.** If there's a tie or no clear winner, ask the user.
4. **Spot-check a few files** to confirm. E.g. if you picked feature-based, open one feature folder and confirm it actually contains components/hooks/api locally — not just an empty shell.
5. **Record the pattern** in the audit summary and in `unslop/issues.json` under `meta.architecturePattern`.

## Detecting deviations

Once the pattern is set, walk the source tree once and flag every file that doesn't fit:

- **Type-based:** flag any `features/`, `modules/`, or domain-named top-level folder.
- **Feature-based:** flag top-level `components/`, `hooks/`, `utils/` (those should be inside `shared/` or inside a feature).
- **Atomic:** flag components that should be in `atoms/` but are sitting in `organisms/` (judgment call — flag conservatively).
- **Next.js app-router + shared:** flag components that live under a route folder but are imported from elsewhere (they should be in shared). Flag shared components that are only used by one route (they should be co-located).

For each deviation, add an entry to the `architecture-inconsistency` category with:
- the file path,
- the dominant pattern,
- a one-line explanation of why this file deviates,
- a suggestion (move where).

## Edge cases

- **Monorepos.** If the project is a monorepo (workspaces or `apps/`+`packages/`), pick the pattern for the app the user pointed at. Don't try to unify across packages without asking.
- **Migration in progress.** If you see signs the team is moving from one pattern to another (e.g. half the code is feature-based, half is type-based, and there's a recent feature-based addition), say so explicitly in the summary rather than picking a winner. Recommend completing the migration.
- **Tiny projects.** Under ~30 files, "pattern" is probably overdetermined. Don't flag inconsistencies — just note that the project is small enough that any pattern works.
