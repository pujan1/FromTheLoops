# Workflow discovery

The skill needs to enumerate user-facing workflows and document each one's happy path, error paths, and loading state.

## What counts as a workflow

A workflow is a coherent sequence the user goes through to accomplish a thing. Anchored by a route (or set of routes), it has:
- a goal,
- a start state,
- a happy-path end state,
- one or more failure modes,
- a loading interval in between.

Examples: sign-in, sign-up, password reset, checkout, search, profile edit, account deletion, settings change, item creation, item deletion.

A single route can host more than one workflow (e.g. `/account` is "view profile" *and* "edit profile" *and* "delete account").

## Discovery procedure

### Step 1 — Enumerate routes

**Next.js app router (`app/`):** find every `page.tsx` (and `route.ts` for API routes, though those are out of scope). The folder path is the URL.

**Next.js pages router (`pages/`):** find every `.tsx` file. The path is the URL.

**React Router / TanStack Router / etc.:** find the route config. Look for `<Route ... />` declarations or a routes object.

### Step 2 — Group routes into workflows

A route is not necessarily a workflow. Group related routes:
- `/login`, `/signup`, `/forgot-password` → three separate workflows under "auth".
- `/products`, `/products/[id]`, `/cart`, `/checkout`, `/order/[id]` → arguably one "purchase" workflow with five steps, or two workflows ("browse" and "checkout"). Pick the framing that matches what the user actually does in one sitting.
- `/dashboard` with multiple tabs → likely one workflow per tab.

Don't be precious about it. Pick a sensible grouping; the user can rename in the report.

### Step 3 — For each workflow, trace the code

Start at the route component. Walk the import graph one level deep. Identify:

- **Components rendered.** What's the visible tree?
- **Data dependencies.** What hooks / fetchers does this route call? (`useQuery`, `useSWR`, `fetch`, Server Components reading from a database.)
- **Mutations.** What actions can the user take? (form submits, button clicks that POST/PATCH.)
- **Navigation out.** Where does the user go on success / failure?

Don't go beyond one level of imports — you'll drown. The point is to map the workflow, not generate a call graph.

### Step 4 — Identify the paths

For each workflow:

**Happy path.** Walk through "user fills form, submits, succeeds." What component renders the success state? Is there a redirect? A toast?

**Error paths.** Brainstorm by category:
- *Validation error* — user input is bad. Is there inline error rendering? Or only a generic toast?
- *Network error* — fetch fails. Is there a retry? An error UI? Or just a blank component?
- *Unauthorised* — user hits a route they shouldn't see. Is there a redirect to login? A 403 page?
- *Not found* — 404 case. Is there a 404 component?
- *Empty state* — query returns no data. Is there a "no results" UI, or just a blank list?

For each, find the corresponding code or note its absence. **Absent paths are themselves findings** — they show up as `missing-loading-states` / `missing-error-boundaries` / etc. in the issue list, *and* they get noted in the workflow doc.

**Loading state.** While the data is fetching / the form is submitting, what does the user see? A skeleton? A spinner? Nothing?

### Step 5 — Write the workflow doc

Each workflow becomes `unslop/workflows/<slug>.md`. Slug is kebab-case: `sign-in`, `password-reset`, `checkout`.

See `output-format.md` for the exact template.

## What to look for while walking

While tracing each workflow, also keep an eye out for:

- **No loading state.** Add to `missing-loading-states` *and* note in the workflow doc.
- **No error boundary above the route.** Add to `missing-error-boundaries`.
- **Swallowed errors in mutations.** Add to `swallowed-errors`.
- **Data fetching mixed with presentation.** Add to `mixed-data-and-presentation`.
- **Hardcoded route strings in this workflow.** Add to `hardcoded-route-strings`.
- **No tests for this workflow's entry point.** Add to `missing-tests-for-critical-paths`.

So the workflow walk is *also* a high-leverage pass on several rules at once.

## Practical limits

- If the project has >20 distinct workflows, ask the user before mapping all of them. Suggest mapping the top 5–10 critical ones first.
- If a route is clearly internal (admin tool, dev-only page), still list it but mark it lower priority.
- API-only Next.js apps with no UI: skip workflow discovery and tell the user — this skill targets UI workflows.

## Optimisation notes

After mapping a workflow, ask yourself: "Is there anything obviously suboptimal?" Examples:
- A 4-step form that could be 2.
- A login flow that re-validates a JWT on every page navigation.
- A search that hits the server on every keystroke instead of debouncing.

Capture these as free-form notes in the workflow doc under an "Optimisation notes" section. They don't become formal issues — they're suggestions for the user.
